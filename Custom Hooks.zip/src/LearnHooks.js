import React, { useCallback, useMemo, useState } from 'react'
import Child from './Child';

const LearnHooks = () => {

  const [count, setCount] = useState(0);
  const [item, setItem] = useState(0);
  const mydata = useCallback(() => {
    //performing some operations..........
    return item
  },[item])

  return (
    <div>
      <h1>{count}</h1>
      <h1>{item}</h1>
      <Child mydata = {mydata} />
      <button onClick={() => { setCount(count + 1) }}>increase count</button><br />
      <button onClick={() => { setItem(item + 1) }}>increase item</button>
    </div>
  )
}

export default LearnHooks
