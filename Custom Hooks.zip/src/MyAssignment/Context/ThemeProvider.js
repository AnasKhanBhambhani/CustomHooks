import React, { createContext, useEffect, useState } from 'react';
import UseLocalStorage from '../CustomHook/UseLocalStorage';
import ThemeComponent from './ThemeComponent';
import NoteTakingApp from '../BonusTask/NoteTakingApp';
import UseToggle from '../CustomHook/UseToggle';

const ThemeContext = createContext();
const ThemeProvider = () => {
    const [current,handleToggle] = UseToggle('light','dark');


    return (
        <ThemeContext.Provider value={{ current, handleToggle }}>
            <ThemeComponent />
            <h1 className='text-2xl font-bold'>Bonus Tasks</h1>
        </ThemeContext.Provider>
    );
};

export { ThemeProvider, ThemeContext };
