import React, { useContext } from 'react';
import { ThemeContext } from './ThemeProvider';

const ThemeComponent = () => {
    const { current, handleToggle } = useContext(ThemeContext);

    return (
        <div className={`p-8 ${current === 'light' ? 'bg-white text-black' : 'bg-black text-white'}`}>
            <p>{current}</p>
            <button onClick={handleToggle} className='px-4 py-2 bg-red-600'>Toggle Theme</button>
        </div>
    );
};

export default ThemeComponent;
