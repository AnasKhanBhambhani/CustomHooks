import React, { useEffect, useState } from 'react'

const UseDimension = () => {
    const [dimen, setDimen] = useState({
        width: window.innerWidth,
        height: window.innerHeight
    });
    useEffect(() => {
        function handleSize() {
            setDimen({

                width: window.innerWidth,
                height: window.innerHeight

            })
        }
        window.addEventListener('resize', handleSize)
        return () => {
            window.removeEventListener('resize', handleSize)
        }
    }, [])
    return dimen
}

export default UseDimension
