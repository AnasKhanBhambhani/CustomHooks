import React from 'react'
import { useState } from 'react'
import UseLocalStorage from './UseLocalStorage';

const UseToggle = (a,b) => {
    const [current,setCurrent] = useState(a);

    function handleToggle(){
setCurrent((precurrent)=>precurrent===a ? b : a )
    }
return [current,handleToggle]
}

export default UseToggle
