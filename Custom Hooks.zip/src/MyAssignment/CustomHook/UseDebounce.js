import React, { useEffect, useState } from 'react'

const UseDebounce = (value) => {
    console.log(value);
    const [bouncedValue, setBouncedValue] = useState(value);
    useEffect(() => {
        const timer = setTimeout(() => {
            setBouncedValue(value)
        }, 1000);
        return () => {
            clearTimeout(timer);
        }
    }, [value])
    return bouncedValue
}

export default UseDebounce
