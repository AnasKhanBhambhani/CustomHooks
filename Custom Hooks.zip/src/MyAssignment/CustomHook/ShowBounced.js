import React from 'react'
import { useState } from 'react'
import UseDebounce from './UseDebounce';

const ShowBounced = () => {
    const [value, setValue] = useState('');
    const debouncedData = UseDebounce(value);
    const handleValue = (e) => {
        setValue(e.target.value)
    }

    return (
        <div>
            <input type="text" value={value} onChange={handleValue} />
            <h1>{debouncedData}</h1>
        </div>
    )
}

export default ShowBounced
