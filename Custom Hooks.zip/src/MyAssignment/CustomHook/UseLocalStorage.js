import React, { useEffect, useState } from 'react'

const UseLocalStorage = (key, Value) => {
    const [current, setCurrent] = useState(() => {
        const item = localStorage.getItem(key);
        return item ? item : Value;
      });

    useEffect(() => {
        localStorage.setItem(key, current);
        console.log(current);
        return () => {
            localStorage.removeItem(key);
          };
    }, [current])
    return [current, setCurrent]
}

export default UseLocalStorage
