import React from 'react'
import UseToggle from './UseToggle'

const ToggleResult = () => {
    const [toggle,handleToggle] = UseToggle(true,false);
  return (
    <div>
      {toggle? <h1 className='p-10 bg-slate-400'>this is a box</h1> : <h1></h1> }
      <button onClick={handleToggle} className='bg-fuchsia-500 px-7 py-4'> {toggle?'hide':'show'} the component</button>
    </div>
  )
}

export default ToggleResult
