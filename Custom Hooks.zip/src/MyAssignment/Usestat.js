import React, { useState } from 'react'

const Usestat = () => {
    const[count,setCount] = useState(0);
  return (
    <div className='bg-slate-300 p-5'>
<h1> {count}</h1><br />
<button onClick={()=>{setCount(count+1)}}>increment it</button><br />
<button onClick={()=>{setCount(count-1)}}>decrement it</button><br />
<button onClick={()=>{setCount(0)}}>reset it</button>
    </div>
  )
}

export default Usestat
