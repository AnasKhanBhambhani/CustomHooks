import React, { useState } from 'react'
import UseLocalStorage from '../CustomHook/UseLocalStorage';
import UseToggle from '../CustomHook/UseToggle';
import UseDebounce from '../CustomHook/UseDebounce';
import UseDimension from '../CustomHook/UseDimension';

const NoteTakingApp = () => {
    const [text, setText] = useState('');

    const [current, setCurrent] = UseLocalStorage('theme', '');
    const [notes, setNotes] = UseLocalStorage('notes', '');
const {width,height} = UseDimension();
console.log(width,height);
    const bouncedValue = UseDebounce(text);

    function handleToggle() {
       setCurrent((prevalue) => prevalue === 'light' ? 'dark' : 'light')
    }



    return (
        <div className={`min-h-screen flex flex-col p-8 ${current === 'light' ? 'bg-white text-black' : 'bg-black text-white'}`}>
            <div>
                <button
                    onClick={() => { handleToggle() }}
                    className="mb-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700" >
                    Toggle Theme
                </button>
            </div>
            <h1 className="text-2xl mb-4">Note Taking App</h1>
            <div>
                <textarea name="notes" id="notes" rows="14" cols="100" value={notes} onChange={(e)=>{setNotes(e.target.value)}} className={`border-4 ${current === 'light' ? 'bg-white text-black' : 'bg-black text-white'}`} />
            </div>
            <div>
                <input type="text" className='p-4 border-2' placeholder='search your note...' value={text} onChange={(e) => { setText(e.target.value) }} />
                <h1>{bouncedValue}</h1>
            </div>
            <div>
<h1>Window Dimension is: {width}x{height} </h1>
            </div>
        </div>
    )
}

export default NoteTakingApp
