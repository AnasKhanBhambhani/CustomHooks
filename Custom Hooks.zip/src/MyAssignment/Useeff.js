import React, { useEffect, useState } from 'react'

const Useeff = () => {
    const [number, setNumber] = useState(0);

    useEffect(() => {

   const randomNumber =      setInterval(() => {
            setNumber(Math.floor(Math.random() * 1000))

        }, 3000);

        return () => {
            clearInterval(randomNumber)
        }
    }, [number])

    return (
        <div className='bg-blue-200'>
        <h1>random no : {number}</h1>
        </div>
    )
}

export default Useeff
