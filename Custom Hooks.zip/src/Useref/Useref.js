import React, { useState } from 'react'
import { useRef } from 'react';

const Useref = () => {
    const ref = useRef(0);
function handleClick(){
console.log('clicked');
ref.current.value = ref.current.value+1
ref.current.focus();
ref.current.style.color = 'red';

}
  return (
    <div>
    <input type="text" ref={ref} />
    <br />
    <button onClick={handleClick}>handle inputs</button>
    <br />
    </div>
  )
}

export default Useref
