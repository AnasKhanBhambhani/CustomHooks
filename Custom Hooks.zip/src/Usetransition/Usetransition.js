import React, { useState, useTransition } from 'react'

const Usetransition = () => {
  const [item, setItem] = useState(['item1', 'item2', 'item3']);
  const [ispending, startTransition] = useTransition({
    timeoutMS:500
  });
  function handleClick(index) {
    startTransition(() => {
      setItem((preItem) => {
        const updateItem = [...preItem];
        updateItem.splice(index, 1);
        return updateItem;
      })
    })
  }
  return (
    <div>
    {ispending && <div> Loading......</div> }
      <ul>
        {item.map((item, index) => {
          return (
            <li onClick={() => { handleClick(index) }}>{item}</li>
          )
        })}
      </ul>
    </div>
  )
}

export default Usetransition
