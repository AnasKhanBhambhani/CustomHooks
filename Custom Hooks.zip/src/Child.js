import {React, memo} from 'react'

const Child = ({mydata}) => {
    console.log('child is running.....');
  return (
    <div>
      {mydata()}
    </div>
  )
}

export default memo(Child)
