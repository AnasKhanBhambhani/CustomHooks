import React, { useContext } from 'react'
import { data1} from '../App'
const ChildC = () => {
    const fname = useContext(data1);
    return (
        <div>
         <h1>my name is {fname.name} </h1>
         <h1>my age is {fname.age} </h1>
         <h1>my gendar is {fname.gendar} </h1>

        </div>
    )
}

export default ChildC
