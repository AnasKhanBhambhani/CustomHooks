import React from 'react'
import ChildC from './ChildC'

const Childb = () => {
  return (
    <div>
      <ChildC/>
    </div>
  )
}

export default Childb
