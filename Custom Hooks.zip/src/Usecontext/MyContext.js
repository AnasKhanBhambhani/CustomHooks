import React, { useContext } from 'react'
import ChildA from './ChildA'

const MyContext = () => {


  return (
    <div>
      <ChildA/>
    </div>
  )
}

export default MyContext
