import React from 'react'
import Childb from './Childb'

const ChildA = () => {
  return (
    <div>
      <Childb/>
    </div>
  )
}

export default ChildA
