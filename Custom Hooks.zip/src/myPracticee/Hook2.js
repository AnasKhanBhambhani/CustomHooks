import React from 'react'
import Hook3 from './Hook3'

const Hook2 = () => {
  return (
    <div>
      <Hook3/>
    </div>
  )
}

export default Hook2
