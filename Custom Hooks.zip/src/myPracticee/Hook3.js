import React, { useContext } from 'react'
import { data1 } from '../App'

const Hook3 = () => {
  let mydata = useContext(data1);
  return (
    <div>
    <h1>{mydata.name}</h1>
    <h1>{mydata.age}</h1>
    <h1>{mydata.gender}</h1>
    </div>
  )
}

export default Hook3
