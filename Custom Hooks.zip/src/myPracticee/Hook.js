import React from 'react'
import Hook2 from './Hook2'

const Hook = () => {
  return (
    <div>
<Hook2/>

    </div>
  )
}

export default Hook
