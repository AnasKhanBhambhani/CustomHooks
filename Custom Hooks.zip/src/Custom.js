import React from 'react'
import { useState, useEffect } from 'react';

const Custom = () => {
    const [isOnline, setIsOnline] = useState(true);
    useEffect(() => {
        function online() {
            setIsOnline(true)
        }
        function offline() {
            setIsOnline(false)
        }
        window.addEventListener('online',online);
        window.addEventListener('offline',offline);
        return ()=>{
            window.removeEventListener('online',online);
            window.removeEventListener('offline',offline);
        }
    }, []);
    function handleSaveClick() {
        console.log('✅ Progress saved');
      }
    return (
        <button disabled={!isOnline} onClick={handleSaveClick}>
      {isOnline ? 'Save progress' : 'Reconnecting...'}
    </button>
    )
}

export default Custom
