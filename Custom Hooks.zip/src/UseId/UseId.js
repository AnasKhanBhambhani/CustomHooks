import React, { useId } from 'react'

const UseId = (props) => {
    const id = useId();
    return (
        <div className='flex flex-col'>
            <div>
                <h1 className='text-2xl font-bold'>{props.title}</h1>
            </div>
            <div className='flex flex-col'>
                <label htmlFor={id+'fname'}>First Name</label>
                <input type="text" name="" id={id+'fname'} />
            </div>
            <br />
            <div className='flex flex-col'>
                <label htmlFor={id+'lname'}>Last Name</label>
                <input type="text" name="" id={id+'lname'} />
            </div>
        </div>
    )
}

export default UseId
