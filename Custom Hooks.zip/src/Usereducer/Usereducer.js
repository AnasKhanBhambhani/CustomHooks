import React, { useReducer, useState } from 'react'

const Usereducer = () => {
    const [data, setData] = useState(0);
    const initialstate = 0;
    const reducer = (state, action) => {
        switch (action) {
            case 'Increment':
                return state + 1
            case 'Decrement':
                return state - 1
            default:
                return state
        }
    }
    const [count, dispatch] = useReducer(reducer, initialstate)
    return (
        <div>
            {data} <br />
            {count} <br />

            <button onClick={() => { setData(data + 1) }}>Increment</button><br />
            <button onClick={() => { setData(data - 1) }}>decrement</button><br />
            <button onClick={() =>  dispatch('Increment') }>Increment red</button><br />
            <button onClick={() =>  dispatch('Decrement') }>decrement red</button>
        </div>
    )
}

export default Usereducer
