import React from 'react';
import ReactDOM from 'react-dom';
import { ThemeProvider } from './MyAssignment/Context/ThemeProvider';
import ThemeComponent from './MyAssignment/Context/ThemeComponent';
import Usestat from './MyAssignment/Usestat';
import Useeff from './MyAssignment/Useeff';
import ShowBounced from './MyAssignment/CustomHook/ShowBounced';
import ToggleResult from './MyAssignment/CustomHook/ToggleResult';
import NoteTakingApp from './MyAssignment/BonusTask/NoteTakingApp';

const App = () => {
    return (
        <div className='container bg-orange-500 w-[100vw] flex flex-col justify-center items-center gap-5'>
            <div className='bg-cyan-100 p-9 flex flex-col gap-5 w-[100vw]'>
                <h1 className='text-2xl font-bold'>Task 1</h1>
                <h6 className='text-xl font-bold'>1.1 usestate</h6>
                <Usestat />
                <h6 className='text-xl font-bold'>1.2 useeffect</h6>
                <Useeff />
                <h6 className='text-xl font-bold'>1.3 useContext</h6>
                <ThemeProvider />
            </div>
            <div className='bg-cyan-300 p-9 flex flex-col gap-5 w-[100vw]'>
                <h1 className='text-2xl font-bold'>Task 2</h1>
                <h6 className='text-xl font-bold'>2.1 localStorage & bonus task also</h6>
                <NoteTakingApp/>
                <h6 className='text-xl font-bold'>2.2 usedebounce</h6>
                <ShowBounced />
                <h6 className='text-xl font-bold'>2.3 usetoggle</h6>
                <ToggleResult />
            </div>
        </div>
    );
};

export default App;

ReactDOM.render(<App />, document.getElementById('root'));
